package jdbcConnectionStudent;


import java.sql.SQLException;
import java.util.Scanner;

public class MainStudentApp {

	public static void main(String[] args) throws SQLException {
		int ch;
		for(;;) {
		Scanner sc = new Scanner(System.in);
		System.out.println("**********MENU****************");
		System.out.println("Enter your choice");
		System.out.println("1. Show student details");
		System.out.println("2.Register Student");
		System.out.println("3.Delete Student Details");
		System.out.println("4.Update Student details");
		System.out.println("5.Exit");
		
		ch = sc.nextInt();
		switch(ch) {
		case 1:// display student details
			DatabaseOperation.displayStdentDetails();
			    break;
		case 2:// display student details
			DatabaseOperation.registerStudent();
			    break;
		case 3:
			DatabaseOperation.deleteStudentDetail();
		    break;
		    
		case 4:
			DatabaseOperation.updateStudentDetail();
		    break;
		case 5:
			System.out.println("exit");
		   System.exit(0);
		}
		
	}

}
}
