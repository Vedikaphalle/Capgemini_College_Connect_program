package jdbcConnectionStudent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;

public class DatabaseOperation {
	 private static Connection conn;
	  private static Statement stmt;
	 private static PreparedStatement pst;
	  private static String sql;
	  private static ResultSet rs;
	  
	  private static String name,email;
	  private static int id;
	  private static float fees;
	  private static Date dob;
	  
		public static void displayStdentDetails() throws SQLException {
			
			conn = DatabaseConnetion.getConnection();
			
			//System.out.println("connection "+conn);
			
			//stmt = conn.createStatement();
			
			
			sql= "select * from student";
			
			pst = conn.prepareStatement(sql);
			//rs = stmt.executeQuery(sql);
			
			rs = pst.executeQuery();
			System.out.println("Id\tName\tfees\tdob\t\temail");
			System.out.println("----------------------------------------------------");
			while(rs.next()) {
				id = rs.getInt("studentid");
				name = rs.getString("studentname");
				email = rs.getString("studentemail");
				fees = rs.getFloat("studentfees");
				dob = rs.getDate("studentdob");
				
				System.out.println(id+"\t"+name+"\t"+fees+"\t"+dob+"\t"+email);
			}
			
			
		}
		public static void registerStudent() throws SQLException{
			conn = DatabaseConnetion.getConnection();
			 Scanner sc = new Scanner(System.in);
			 System.out.print("name: ");
	         String name = sc.next();
	         System.out.print("email: ");
	         String email = sc.next();
	         System.out.print("fees: ");
	         float fees = sc.nextFloat();
	         System.out.print("DOB(yyyy-mm-dd): ");
	         String dob = sc.next();
	         
	         stmt = conn.createStatement();
	         
	         String s="select max(studentid)+1 as id from student";
	         rs=stmt.executeQuery(s);
	         int sid = 0;
	         if(rs.next()) {
	        	 sid=rs.getInt("id");
	 		}
		
	         String ins = "insert into student(studentid,studentname,studentemail,studentfees,studentdob) values(?,?,?,?,?)";
	         pst=conn.prepareStatement(ins);
	         pst.setInt(1, sid);
	         pst.setString(2, name);
	         pst.setString(3, email);
	         pst.setFloat(4, fees);
	         pst.setString(5, dob);
	         
	         int i=pst.executeUpdate();
	         if(i>0) {
	        	 System.out.println("Record added");
	 		}else {
	 			System.out.println("Error occured");
	 		}
		}
		
       public static void deleteStudentDetail() throws SQLException{
    	   conn = DatabaseConnetion.getConnection();
    	   Scanner sc = new Scanner(System.in);
    	   System.out.println("enter student to delete record:");
    	   id=sc.nextInt();
    	   
    	   String sql="select * from student where studentid=?";
    	   pst=conn.prepareStatement(sql);
    	   pst.setInt(1, id);
    	   
    	   rs=pst.executeQuery();
    	   
    	   if(rs.next()) {
    		   String del="delete from student where studentid=?";
    		   pst=conn.prepareStatement(del);
    		   pst.setInt(1, id);
    		   
    		   int i=pst.executeUpdate();
    		   if(i>0) {
   				System.out.println("deleted the record");
   			}
   			
   		}else {
   			System.out.println("User not exists cannot delete record");
   		}
    		   
     }
			
		
       public static void updateStudentDetail() throws SQLException{
    	   conn = DatabaseConnetion.getConnection();
    	   stmt = conn.createStatement();
			
    	   Scanner sc = new Scanner(System.in);
    	   System.out.println("*****Update******");
    	   System.out.println("1.Update name");
    	   System.out.println("2.Update email");
    	   System.out.println("3.Update fees");
    	   System.out.println("4.Update dob");
    	   System.out.println("enter the choice : " );
    	   
    	   int ch = sc.nextInt();
    	   switch(ch) {
    	   case 1:
    		   System.out.println("Enter student id");
    		    id = sc.nextInt();
    			
    			String s = "select * from student where studentid=?";
    			pst=conn.prepareStatement(s);
    			pst.setInt(1, id);
    			ResultSet rs = pst.executeQuery();
    			
    			if(rs.next()) { 
    				System.out.println("Enter new name");
    				sc.nextLine();
    				String newpass = sc.nextLine();
    			
    				String supname = "update student set studentname=? where studentid=?";
    				pst=conn.prepareStatement(supname);
    				pst.setString(1, supname);
    				pst.setInt(2, id);
    				int i = pst.executeUpdate();
    				if(i>0) {
    					System.out.println("name is updated");
    				}
    				
    			 }else {
    				System.out.println("User not exists cannot change name");
    			}
    			break;
    	   case 2:
    		   System.out.println("Enter student id");
   		       id = sc.nextInt();
   			
   			   String s1 = "select * from student where studentid=?";
   			   pst=conn.prepareStatement(s1);
   			   pst.setInt(1, id);
   			   rs = pst.executeQuery();
   			
   			   if(rs.next()) { 
   				System.out.println("Enter new email");
   				String newemail = sc.next();
   			
   				String supemail = "update student set studentemail=? where studentid=?";
   				pst=conn.prepareStatement(supemail);
   				pst.setString(1, supemail);
   				pst.setInt(2,id);
   				int i = pst.executeUpdate();
   				if(i>0) {
   					System.out.println("email is updated");
   				}
   				
   			    }else {
   				System.out.println("User not exists cannot change email");
   			    }
    		   break;
    		  
    	   case 3:
    		System.out.println("Enter student id");
   		    id = sc.nextInt();
   			
   			String s2 = "select * from student where studentid=?";
   			pst=conn.prepareStatement(s2);
   			pst.setInt(1, id);
   			rs = pst.executeQuery();
   			
   			if(rs.next()) { 
   				System.out.println("Enter new fees");
   				float newfees = sc.nextFloat();
   			
   				String supdate = "update student set studentfees=? where studentid=?";
   				pst=conn.prepareStatement(supdate);
   				pst.setFloat(1, newfees);
   				pst.setInt(2, id);
   				int i = pst.executeUpdate();
   				if(i>0) {
   					System.out.println("fees is updated");
   				}
   				
   			 }else {
   				System.out.println("User not exists cannot change fees");
   			}
   			break;
   			
    	   case 4:
    		   System.out.println("Enter student id");
   		       id = sc.nextInt();
   			
   			String s3 = "select * from student where studentid=?";
   		   pst=conn.prepareStatement(s3);
  	      pst.setInt(1, id);
   			rs = pst.executeQuery();
   			
   			if(rs.next()) { 
   				System.out.println("Enter new dob");
   				String newdob = sc.next();
   			
   				String supdate = "update student set studentdob=? where studentid=?";
   				pst=conn.prepareStatement(supdate);
   				pst.setString(1, newdob);
   				pst.setInt(2, id);
   				int i = pst.executeUpdate();
   				if(i>0) {
   					System.out.println("DOB is updated");
   				}
   				
   			 }else {
   				System.out.println("User not exists cannot change DOB");
   			} 
    		   
    			
    			
    	   }
    	   
		}
		
	}