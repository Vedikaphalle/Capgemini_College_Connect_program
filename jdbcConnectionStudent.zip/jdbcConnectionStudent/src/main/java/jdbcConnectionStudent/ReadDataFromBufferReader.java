package jdbcConnectionStudent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.Format;

public class ReadDataFromBufferReader {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
        int eid;
        String ename;
        float esalary;
           
        
        //InputStreamReader is=new  InputStreamReader(System.in);
       // BufferedReader br= new BufferedReader(is);
        BufferedReader br= new BufferedReader(new  InputStreamReader(System.in));
        //read()-> ascii value
        //readLine()->String
        
        System.out.println("enter emplyoee id");
        eid=Integer.parseInt(br.readLine());
        
        System.out.println("enter name");
        ename=br.readLine();
        
        //System.out.println("enter salary");
        //esalary=Float.parseFloat(br.readLine());
        
        System.out.println("name ="+ename);
        System.out.println("eid ="+eid);
       // System.out.println("salary ="+esalary);
        
	}

}
